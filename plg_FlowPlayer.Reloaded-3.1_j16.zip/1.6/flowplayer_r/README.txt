assets      - player's internal files. No need to modify them.
javascripts - ONLY flowplayer's CORE JAVASCRIPT files
players     - ONLY flowplayer's SWF CORE files (both standard and your custom builds)
swfplugins  - PLUGINS for core swf files :: both js and swf flowplayer's plugins

So, if you want to add iPad plugin (for instance), you should put its js to swfplugins folder.

(I could rename folders in more intuitive way, but that's impossible due to compatibility issues with older versions).